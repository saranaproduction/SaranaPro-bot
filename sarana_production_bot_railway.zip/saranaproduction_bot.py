
from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import (
    ApplicationBuilder, CommandHandler, CallbackQueryHandler,
    ContextTypes
)
import os

TOKEN = os.getenv("BOT_TOKEN")

def main_menu():
    keyboard = [
        [InlineKeyboardButton("📢 Layanan Kami", callback_data='layanan')],
        [InlineKeyboardButton("📱 Kontak", callback_data='kontak')],
        [InlineKeyboardButton("ℹ️ Tentang Kami", callback_data='tentang')]
    ]
    return InlineKeyboardMarkup(keyboard)

def layanan_menu():
    keyboard = [
        [InlineKeyboardButton("📌 Meeting", callback_data='meeting')],
        [InlineKeyboardButton("🏢 Convention", callback_data='convention')],
        [InlineKeyboardButton("💡 Invention", callback_data='invention')],
        [InlineKeyboardButton("🎪 Exhibition", callback_data='exhibition')],
        [InlineKeyboardButton("🔙 Kembali", callback_data='back')]
    ]
    return InlineKeyboardMarkup(keyboard)

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "Selamat datang di *SARANA PRODUCTION*! 🎉\n\nSilakan pilih menu di bawah:",
        reply_markup=main_menu(),
        parse_mode='Markdown'
    )

async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    if query.data == 'layanan':
        await query.edit_message_text("Pilih jenis layanan kami:", reply_markup=layanan_menu())
    elif query.data == 'meeting':
        await query.edit_message_text(
            "📌 *Meeting*\n\nKami menyediakan layanan meeting profesional dengan peralatan modern dan dukungan penuh tim kami.",
            parse_mode='Markdown',
            reply_markup=layanan_menu()
        )
    elif query.data == 'convention':
        await query.edit_message_text(
            "🏢 *Convention*\n\nLayanan konvensi skala besar yang terorganisir dengan baik dan efisien.",
            parse_mode='Markdown',
            reply_markup=layanan_menu()
        )
    elif query.data == 'invention':
        await query.edit_message_text(
            "💡 *Invention*\n\nFasilitasi inovasi dan peluncuran ide kreatif Anda bersama SARANA PRODUCTION.",
            parse_mode='Markdown',
            reply_markup=layanan_menu()
        )
    elif query.data == 'exhibition':
        await query.edit_message_text(
            "🎪 *Exhibition*\n\nPameran profesional dengan desain booth dan layout terbaik.",
            parse_mode='Markdown',
            reply_markup=layanan_menu()
        )
    elif query.data == 'kontak':
        await query.edit_message_text(
            "📱 *Kontak Kami*\n\n"
            "📞 WhatsApp: [0896-9280-1045](https://wa.me/6289692801045)\n"
            "📸 Instagram: [@sarana.productions](https://www.instagram.com/sarana.productions)",
            parse_mode='Markdown',
            disable_web_page_preview=True,
            reply_markup=main_menu()
        )
    elif query.data == 'tentang':
        await query.edit_message_text(
            "ℹ️ *Tentang SARANA PRODUCTION*\n\n"
            "Kami adalah penyedia layanan Meeting, Convention, Invention, dan Exhibition terpercaya "
            "yang mengutamakan pelayanan terbaik, tim berpengalaman, dan teknologi mutakhir.",
            parse_mode='Markdown',
            reply_markup=main_menu()
        )
    elif query.data == 'back':
        await query.edit_message_text("Silakan pilih menu di bawah:", reply_markup=main_menu())

if __name__ == '__main__':
    app = ApplicationBuilder().token(TOKEN).build()
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CallbackQueryHandler(button_handler))
    print("Bot berjalan...")
    app.run_polling()
